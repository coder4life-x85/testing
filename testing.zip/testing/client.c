#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <pthread.h>

int sockfd;
int sockfd2[150];

int count = 0;

void *do_this(void *arg)
{
	while(1) {
        printf("%d\n", count);
    }
}
int main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *hostname = "69.156.217.67";
    const int port = 47832;

    struct hostent *host;
    struct sockaddr_in server_addr;

    int val = 1;
    /*
        for (int i = 0; i < 150; i++)
        {
            sockfd2[i] = socket(AF_INET, SOCK_STREAM, 0);
        }
    */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    inet_pton(AF_INET, hostname, &server_addr.sin_addr.s_addr);
    char buf[64] = {0};
    /*
        for (int i = 0; i < 150; i++)
        {
            while (connect(sockfd2[i], (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
            {
                printf("Failed with errno number : %d, %d\n", errno, i);
            }
            printf("Connected. %d", sockfd2[i]);
        }
    */
    // Connect to server
    while (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        printf("Failed with errno number : %d, 1\n", errno);
        usleep(10000);
    }

    char port_recv[32];

    int port_int;
    printf("%d", sockfd);
    read(sockfd, buf, sizeof(buf));
    read(sockfd, port_recv, sizeof(port_recv));
    close(sockfd);
    port_int = atoi(port_recv);
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(47832);
    hostname = buf;

    int sockfd2 = socket(AF_INET, SOCK_STREAM, 0);
    host = gethostbyname(hostname);

    memcpy(&server_addr.sin_addr, host->h_addr, host->h_length);

    while (connect(sockfd2, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        printf("Failed with errno number : %d, 2\n", errno);
    }
    
    printf("Succesfully connected to %s!!", hostname);

    char message[1024] = "Hello, world!!!";

	pthread_t thread;

	pthread_create(&thread, 0, do_this, 0);
    while (1)
    {
        if (send(sockfd2, message, sizeof(message), 0) != -1)
        {
            count++;
        }

        else
        {
            printf("FAILED.");
        }
    }
}
