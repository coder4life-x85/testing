#include <WinSock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <time.h>
#include <windows.h>
#define MAX_CLIENTS 99999999
int sock[10] = { -1 };
int server = 0;
struct sockaddr_in ip_client = {0};
int ip_size = sizeof(ip_client);
int row = 0;
int col = 0;
int count = 0;
int sock_num = 0;
char client_ip[INET_ADDRSTRLEN];
DWORD WINAPI accept_client(void *arg)
{

	while (1)
	{
		sock[sock_num] = accept(server, (struct sockaddr *)&ip_client, &ip_size);

		inet_ntop(AF_INET, &(ip_client.sin_addr), client_ip, INET_ADDRSTRLEN);

		if (sock[sock_num] != 0)
		{
			count++;
		}
		sock_num++;
	}
}

DWORD WINAPI display_count(void *arg)
{
	while (1)
	{
		printf("\x1b[4;1H[ %d ]", count);
	}
}

int main()
{
	printf("\x1b[?25l");
	WSADATA wsaData;

	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
	{
		fprintf(stderr, "failed to work. R.I.P");
	}

	if (LOBYTE(wsaData.wVersion) != 2 ||
		HIBYTE(wsaData.wVersion) != 2)
	{
		fprintf(stderr, "not updated the winsock lol");
		WSACleanup();
		exit(2);
	}
	system("cls");
	printf("\x1b[34mListening for clients on port 47832");
	struct addrinfo hints = {0};

	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	struct addrinfo *res;
	char *ip = NULL;
	int addr_info = getaddrinfo(ip, "47832", &hints, &res);

	server = socket(res->ai_family, res->ai_socktype, res->ai_protocol); // Make socket using Get addr info results (res)
	if (server == -1) {
    perror("socket");
    exit(EXIT_FAILURE);
}
	bind(server, res->ai_addr, res->ai_addrlen); // Connects the socket to the get addr info socket address (aka example.com)

	listen(server, 50);

	CreateThread(NULL, 0, accept_client, NULL, 0, NULL);
	CreateThread(NULL, 0, display_count, NULL, 0, NULL);
	srand(time(NULL));
	char send_data[512] = {0};
	char send_msg[1024] = {0};
	char recv_data[1024] = {0};
	char position[128] = {0};
	int color = rand() % 255;

	while (1)
	{

		for (int i = 0; i < count; i++)
		{
			row = rand() % 80;
			col = rand() % 25;
			color = rand() % 255;
			int len = snprintf(send_data, sizeof(send_data), "\x1b[?25l\x1b[38;2;%d;%d;%dm\x1b[%d;%dH. ", color, color, color, col, row);

			if (send(sock[i], send_data, len, 0) == -1)
			{
				count--;
				sock_num--;
			}

			int len2 = snprintf(send_msg, sizeof(send_msg), "\033[1m\x1b[12;32Hwelcome to space", 0);
			send(sock[i], send_msg, len2, 0);
		}
	}
}