#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <pthread.h>
#include <ncurses.h>
#include <errno.h>
#include <signal.h>

#define MAX_CLIENTS 99999999

int server = 0;
struct sockaddr_in ip_client = {0};
int ip_size = sizeof(ip_client);
int row = 0;
int col = 0;
int count = 0;
int sock_num = 0;
char client_ip[INET_ADDRSTRLEN];

int sockfd[MAX_CLIENTS];

bool start_sending = 0;
int total_count = 0;
int serverfd;
void *do_this(void *arg)
{
	while (1)
	{
		sockfd[sock_num] = accept(serverfd, (struct sockaddr *)&ip_client, &ip_size);

		if (sockfd[sock_num] == -1)
		{
			printf("FAILED!!!");
		}

		else
		{
			count++;
			sock_num++;
			total_count++;
			start_sending = 1;
		}
	}
}

int main()
{
	signal(SIGPIPE, SIG_IGN);

	struct sockaddr_in server_addr, client_addr, ip_client;

	serverfd = socket(AF_INET, SOCK_STREAM, 0);
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;
	server_addr.sin_port = htons(47832);

	bind(serverfd, (struct sockaddr *)&server_addr, sizeof(server_addr));

	if (listen(serverfd, 50) < 0)
	{
		perror("listen failed");
		exit(1);
	}

	char send_data[512] = {0};
	char send_msg[1024] = {0};
	char recv_data[1024] = {0};
	char position[128] = {0};
	int color = rand() % 255;
	char buf_send[128] = {0};
	char ip_send[64] = "91.228.90.164";
	char port_send[32];
	printf("\x1b[?25l");

	pthread_t thread;

	pthread_create(&thread, 0, do_this, 0);
	initscr();
	refresh();
	start_color();
	init_color(COLOR_CYAN, 500, 804, 984);
	init_pair(1, COLOR_CYAN, COLOR_BLACK);
	init_pair(2, COLOR_CYAN, COLOR_BLACK);
	int width = getmaxx(stdscr);
	int height = getmaxy(stdscr);
	WINDOW *win = newwin(height, width, 0, 0);
	WINDOW *win2 = derwin(win, 3, 22, 1, (width / 2) - 11);
	WINDOW *win3 = newwin(15, 35, 4, width - 67);
	wbkgd(win, COLOR_PAIR(1));
	wbkgd(win2, COLOR_PAIR(1));
	wbkgd(win3, COLOR_PAIR(2));
	wborder(win,
			ACS_VLINE, ACS_VLINE,		// left, right
			ACS_HLINE, ACS_HLINE,		// top, bottom
			ACS_ULCORNER, ACS_URCORNER, // top left, top right
			ACS_LLCORNER, ACS_LRCORNER	// bottom left, bottom right
	);

	wborder(win2,
			ACS_VLINE, ACS_VLINE,		// left, right
			ACS_HLINE, ACS_HLINE,		// top, bottom
			ACS_ULCORNER, ACS_URCORNER, // top left, top right
			ACS_LLCORNER, ACS_LRCORNER	// bottom left, bottom right
	);

	wborder(win3,
			ACS_VLINE, ACS_VLINE,		// left, right
			ACS_HLINE, ACS_HLINE,		// top, bottom
			ACS_ULCORNER, ACS_URCORNER, // top left, top right
			ACS_LLCORNER, ACS_LRCORNER	// bottom left, bottom right
	);

   	mvwprintw(win2, 1, 2, "Enter IPv4 Address");
	mvwprintw(win, 6, 3, "-> ");
	wscanw(win, "%s", ip_send);
	mvwprintw(win2, 1, 2, "Enter Port Number ");
	wrefresh(win2);
	mvwprintw(win, 9, 3, "-> ");
	wscanw(win, "%s", port_send);
    wrefresh(win3);

	while (1)
	{
		if (start_sending)
		{
			for (int i = 0; i < count; i++)
			{
				int ret = send(sockfd[i], ip_send, sizeof(ip_send), 0);
				if (ret == -1)
				{
                    mvwprintw(win3, 3, 7, "%d, %d, %d", errno, sizeof(ip_send), sockfd[i]);
					close(sockfd[i]);
					count--;
					sock_num--;
				    
                }
			}

			mvwprintw(win3, 2, 7, "Total Clients [ %d ]", total_count);
			wrefresh(win3);
		}
	}
}
